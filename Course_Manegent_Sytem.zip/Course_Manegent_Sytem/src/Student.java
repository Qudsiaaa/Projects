public class Student extends EnrolledStudent
{

    public Student(String name, String address, int age)
    {
        super(name, address, age);
    }

}
